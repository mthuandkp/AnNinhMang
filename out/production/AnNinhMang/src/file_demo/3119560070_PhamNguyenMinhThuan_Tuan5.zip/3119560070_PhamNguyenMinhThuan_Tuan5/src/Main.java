import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        HashMap<String,String> hashMap = new HashMap<>();

        hashMap = readFile();
        String plaintext = hashMap.get("plaintext");
        hashMap.remove("plaintext");

        String encryptText = encrypt(plaintext,hashMap);
        String decrypt = decrypt(encryptText,hashMap);

        System.out.println(encryptText);
        System.out.println(decrypt);
    }

    private static String decrypt(String encryptText, HashMap<String, String> hashMap) {
        String plaintext = "";
        for(Character c : encryptText.toCharArray()){
            String strCharacter = c.toString();
            for(Map.Entry<String,String> entry : hashMap.entrySet()){
                if(strCharacter.equals(entry.getValue())){
                    plaintext += entry.getKey();
                    break;
                }
            }
        }

        return plaintext;
    }

    private static String encrypt(String plaintext, HashMap<String, String> hashMap) {
        String encryptText = "";
        for(Character c : plaintext.toCharArray()){
            String character = c.toString();
            encryptText += hashMap.get(character);
        }

        return encryptText;
    }

    private static HashMap<String, String> readFile() {
        HashMap<String,String> hashMap = new HashMap<>();
        try {
            File myObj = new File("./src/secret.txt");
            Scanner myReader = new Scanner(myObj);
            String secret = myReader.nextLine();
            String plaintext = myReader.nextLine();

            String []secretSplit = secret.split(" ");
            for(int i = 0;i < 26;i++){
                hashMap.put(new Character((char)(i+97)).toString(),secretSplit[i] );
            }

            hashMap.put("plaintext",plaintext);


            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        return hashMap;
    }
}